var EDIT_MODE = "edit";
var VIEW_MODE = "view";

(function($) {

	var metodos = {
			initialMode : VIEW_MODE,
			beforeEdition : function(callback) {
				var data = this.data('form');

				if (data.beforeEdition) {
					data.beforeEdition(callback);
				} else if (callback) {
					callback();					
				}
			},
			fillFormFields : function (objeto) {
				var data = this.data('form');

				if (data.fillFormFields) {
					data.fillFormFields(objeto);
				}
			},
			fillForm : function(callback) {
				var data = this.data('form');
				var self = this;
				
				if (data.fillForm) {
					data.fillForm(callback);
				} else {
					this.form('beforeEdition', function() {
						self.form('fillFormFields');

						if (callback){
							callback();
						}
					});
				}
			},
			setFormMode: function(mode) {
				if (mode == EDIT_MODE) {
					this.form('edit');
				} else {
					this.form('view');
				}
			},
			reset : function() {
				this.form('setFormMode', VIEW_MODE);
				this.form('onReset');
			},
			onReset : function() {
				var data = this.data('form');

				if (data.onReset) {
					data.onReset();
				}
				
			},
			onSubmit: function(event) {
				var data = this.data('form');

				if (data.onSubmit) {
					return data.onSubmit();
				}

				return true;
			},
			edit : function() {
				this.addClass('edicao');
				this.removeClass('visualizacao');
				
				this.form('fillForm');
				this.form('onEdit');
			},
			onEdit : function() {
				var data = this.data('form');

				if (data.onEdit) {
					return data.onEdit();
				}
			},
			view : function() {
				this.addClass('visualizacao');
				this.removeClass('edicao');

				this.form('onView');
			},
			onView : function() {
				var data = this.data('form');

				if (data.onView) {
					return data.onView();
				}
			}
	};
	
	
	$.fn.form = function(metodo) {
		var argumentos = arguments; 

		return this.each(function() {
			if (metodos[metodo]) {
				return metodos[metodo].apply( $(this), Array.prototype.slice.call( argumentos, 1 ));
			} else if ( typeof metodo === 'object') {
				var $this = $(this);

				$this.data('form', metodo); // Na verdade, são dados.

				$this.bind('submit', function(event) {
					return metodos['onSubmit'].call( $this, event);
				});

				$this.bind('reset', function(event) {
					metodos['reset'].call( $this, event);
				});
		    } 
			
			
		});
	};
	
})(jQuery);